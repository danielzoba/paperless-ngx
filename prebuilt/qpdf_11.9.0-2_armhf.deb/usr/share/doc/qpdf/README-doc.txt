Complete documentation for qpdf can be found in the qpdf-doc package or
online at https://qpdf.readthedocs.io
